var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

var app = builder.Build();

// Serve static files from the wwwroot folder
app.UseStaticFiles();

// Configure the HTTP request pipeline.
app.UseRouting();

app.MapGet("/", async context =>
{
    context.Response.ContentType = "text/html";
    await context.Response.SendFileAsync(Path.Combine(app.Environment.WebRootPath, "main.html"));
});

app.Run();
