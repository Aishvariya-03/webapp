﻿document.addEventListener("DOMContentLoaded", function () {
    const studentForm = document.getElementById("studentForm");
    const saveBtn = document.getElementById("saveBtn");
    const cancelBtn = document.getElementById("cancelBtn");

    function validateForm() {
        let isValid = true;

        const fname = document.getElementById("fname");
        const lname = document.getElementById("lname");
        const gender = document.getElementById("gender");
        const age = document.getElementById("age");

        const fnameErrorLabel = document.getElementById("fnameErrorLabel");
        const lnameErrorLabel = document.getElementById("lnameErrorLabel");
        const genderErrorLabel = document.getElementById("genderErrorLabel");
        const ageErrorLabel = document.getElementById("ageErrorLabel");

        if (!fname.value.trim()) {
            fnameErrorLabel.textContent = "Please enter first name";
            isValid = false;
        } else if (fname.value.length < 3 || fname.value.length > 15) {
            fnameErrorLabel.textContent = "First name should be between 3 and 15 characters";
            isValid = false;
        } else {
            fnameErrorLabel.textContent = "";
        }

        if (!lname.value.trim()) {
            lnameErrorLabel.textContent = "Please enter last name";
            isValid = false;
        } else if (lname.value.length < 2 || lname.value.length > 18) {
            lnameErrorLabel.textContent = "Last name should be between 2 and 18 characters";
            isValid = false;
        } else {
            lnameErrorLabel.textContent = "";
        }

        if (!gender.value) {
            genderErrorLabel.textContent = "Please select gender";
            isValid = false;
        } else {
            genderErrorLabel.textContent = "";
        }

        if (!age.value.trim()) {
            ageErrorLabel.textContent = "Please enter age";
            isValid = false;
        } else if (age.value < 5 || age.value > 99) {
            ageErrorLabel.textContent = "Age should be between 5 and 99";
            isValid = false;
        } else {
            ageErrorLabel.textContent = "";
        }

        return isValid;
    }

    function synchronizeAgeAndDob() {

        const dob = document.getElementById("dob");
        const age = document.getElementById("age");

        dob.addEventListener("change", function () {
            const birthDate = new Date(dob.value);
            const today = new Date();
            let ageValue = today.getFullYear() - birthDate.getFullYear();
            const monthDiff = today.getMonth() - birthDate.getMonth();
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                ageValue--;
            }
            age.value = ageValue;
        });

        age.addEventListener("input", function () {
            if (age.value) {
                const ageValue = parseInt(age.value);
                const today = new Date();
                const birthYear = today.getFullYear() - ageValue;
                dob.value = new Date(birthYear, today.getMonth(), today.getDate()).toISOString().substr(0, 10);
            } else {
                dob.value = "";
            }
        });
    }

    function handleFormSubmit(event) {
        event.preventDefault();
        if (!validateForm()) {
            return;
        }
        const formData = new FormData(studentForm);

        const student = {
            firstName: formData.get("fname"),
            lastName: formData.get("lname"),
            age: formData.get("age"),
            gender: formData.get("gender"),
            class: formData.get("class"),
        };

        console.log("New student added:", student);
        addToLocalStorage(student);

        window.location.href = "main.html";
    }

    function handleCancelClick() {
        window.location.href = "main.html";
    }

    function addToLocalStorage(student) {
        let students = JSON.parse(localStorage.getItem("students")) || [];
        students.push(student);
        localStorage.setItem("students", JSON.stringify(students));
        console.log("Students in localStorage:", students);
    }

    studentForm.addEventListener("submit", handleFormSubmit);
    cancelBtn.addEventListener("click", handleCancelClick);

    synchronizeAgeAndDob();
});