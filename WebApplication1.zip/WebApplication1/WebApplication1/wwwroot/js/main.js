﻿document.addEventListener("DOMContentLoaded", function () {
    const defaultStudents = [
        { firstName: 'Kitty', lastName: 'Senaiyar', age: 15, gender: 'Female', class: 7 },
        { firstName: 'Aishu', lastName: 'Meadows', age: 21, gender: 'Female', class: 2 },
    ];

    let storedStudents = JSON.parse(localStorage.getItem("students")) || [];
    console.log("Stored students from localStorage:", storedStudents); // Debugging
    let students = defaultStudents.concat(storedStudents);
    console.log("All students (including defaults):", students); // Debugging

    let selectedRow = null;
    let sortDirection = true; // true for ascending, false for descending

    function displayStudents(studentList) {
        const tbody = document.querySelector("#studentList tbody");
        tbody.innerHTML = ""; // Clear the table body

        studentList.forEach((student, index) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${student.firstName}</td>
                <td>${student.lastName}</td>
                <td>${student.age}</td>
                <td>${student.gender}</td>
                <td>${student.class}</td>
            `;
            row.addEventListener("click", () => selectRow(row));
            row.addEventListener("dblclick", () => editRow(index));
            tbody.appendChild(row);
        });

        if (studentList.length > 0) {
            selectRow(tbody.rows[0]);
        }
    }

    function selectRow(row) {
        if (selectedRow) {
            selectedRow.classList.remove("selected");
        }
        selectedRow = row;
        selectedRow.classList.add("selected");
    }

    document.getElementById("searchBox").addEventListener("input", function () {
        const searchText = this.value.toLowerCase();
        const filteredStudents = students.filter(student =>
            student.firstName.toLowerCase().includes(searchText) ||
            student.lastName.toLowerCase().includes(searchText) ||
            student.age.toString().includes(searchText)
        );
        displayStudents(filteredStudents);
    });

    document.querySelectorAll("#studentList th").forEach(header => {
        header.addEventListener("click", () => {
            const column = header.getAttribute("data-column");
            sortStudents(column);
        });
    });

    function sortStudents(column) {
        students.sort((a, b) => {
            if (a[column] > b[column]) return sortDirection ? 1 : -1;
            if (a[column] < b[column]) return sortDirection ? -1 : 1;
            return 0;
        });
        sortDirection = !sortDirection;
        displayStudents(students);
    }

    displayStudents(students);
});
