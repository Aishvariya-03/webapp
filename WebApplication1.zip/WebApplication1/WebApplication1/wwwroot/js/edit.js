﻿document.addEventListener("DOMContentLoaded", function () {
    const formHeader = document.getElementById("formHeader");
    const studentForm = document.getElementById("studentForm");
    const deleteBtn = document.getElementById("deleteBtn");
    const saveBtn = document.getElementById("saveBtn");
    const cancelBtn = document.getElementById("cancelBtn");

    const fname = document.getElementById("fname");
    const lname = document.getElementById("lname");
    const gender = document.getElementById("gender");
    const dob = document.getElementById("dob");
    const age = document.getElementById("age");
    const classbox = document.getElementById("class");
    const address = document.getElementById("address");

    const fnameError = document.getElementById("fnameError");
    const lnameError = document.getElementById("lnameError");
    const genderError = document.getElementById("genderError");
    const dobError = document.getElementById("dobError");
    const ageError = document.getElementById("ageError");
    const classError = document.getElementById("classError");

    function initializeForm() {
        // Check if we are in Add or Edit mode
        const urlParams = new URLSearchParams(window.location.search);
        const mode = urlParams.get('mode');
        const studentId = urlParams.get('id');

        if (mode === 'edit' && studentId) {
            formHeader.textContent = "Edit Student";
            deleteBtn.style.display = "inline-block";
            // Load the student data based on studentId
            // This is a placeholder, replace with actual data loading logic
            const student = {
                firstName: "John",
                lastName: "Doe",
                gender: "Male",
                dob: "2005-06-15",
                age: 18,
                class: "10",
                address: "123 Main St"
            };
            fname.value = student.firstName;
            lname.value = student.lastName;
            gender.value = student.gender;
            dob.value = student.dob;
            age.value = student.age;
            classbox.value = student.class;
            address.value = student.address;
        } else {
            formHeader.textContent = "Add Student";
            deleteBtn.style.display = "none";
        }
    }

    function validateForm() {
        let isValid = true;

        if (!fname.value.trim()) {
            fnameError.textContent = "This field is required";
            isValid = false;
        } else if (fname.value.length < 3 || fname.value.length > 15) {
            fnameError.textContent = "The field should have minimum 3 and maximum 15 characters";
            isValid = false;
        } else {
            fnameError.textContent = "";
        }

        if (!lname.value.trim()) {
            lnameError.textContent = "This field is required";
            isValid = false;
        } else if (lname.value.length < 2 || lname.value.length > 18) {
            lnameError.textContent = "The field should have minimum 2 and maximum 18 characters";
            isValid = false;
        } else {
            lnameError.textContent = "";
        }

        if (!gender.value) {
            genderError.textContent = "This field is required";
            isValid = false;
        } else {
            genderError.textContent = "";
        }

        if (!dob.value) {
            dobError.textContent = "This field is required";
            isValid = false;
        } else {
            dobError.textContent = "";
        }

        if (!age.value.trim()) {
            ageError.textContent = "This field is required";
            isValid = false;
        } else if (age.value < 5 || age.value > 99) {
            ageError.textContent = "The field value should be between 5 and 99";
            isValid = false;
        } else {
            ageError.textContent = "";
        }

        return isValid;
    }

    function synchronizeAgeAndDob() {
        dob.addEventListener("change", function () {
            const birthDate = new Date(dob.value);
            const today = new Date();
            let ageValue = today.getFullYear() - birthDate.getFullYear();
            const monthDiff = today.getMonth() - birthDate.getMonth();
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                ageValue--;
            }
            age.value = ageValue;
        });

        age.addEventListener("input", function () {
            if (age.value) {
                const ageValue = parseInt(age.value);
                const today = new Date();
                const birthYear = today.getFullYear() - ageValue;
                dob.value = new Date(birthYear, today.getMonth(), today.getDate()).toISOString().substr(0, 10);
            } else {
                dob.value = "";
            }
        });
    }

    function handleFormSubmit(event) {
        event.preventDefault();
        if (validateForm()) {
            // Handle form submission (e.g., save data)
            alert('Form submitted successfully');
        }
    }

    function handleDeleteClick() {
        if (confirm("Are you sure you want to delete this student records?")) {
            // Handle delete logic
            alert('Student record deleted');
        }
    }

    function handleCancelClick() {
        // Close the form or navigate to the list page
        window.location.href = "main.html";
    }

    initializeForm();
    synchronizeAgeAndDob();

    studentForm.addEventListener("submit", handleFormSubmit);
    deleteBtn.addEventListener("click", handleDeleteClick);
    cancelBtn.addEventListener("click", handleCancelClick);
});
